import { series, parallel } from "gulp";
import { wasm } from "./wasm";
import { compileJs, emulators } from "./emulators";
import { test } from "./test";

import { emitTypes } from "./types";
import { updateDosbox } from "./update-dosbox";
import { dosboxAsyncify, dosboxXAsyncify } from "./asyncify";

function build(compress: boolean, debug: boolean) {
    return series(
        wasm(compress, debug),
        compileJs,
        parallel(emulators(debug), test),
    );
}

exports.default = build(false, false);
exports.debug = build(false, true);
exports.production = series(
    build(true, true),
    emitTypes,
);
exports.test = test;
exports.wasm = wasm(false, false);
exports.updateDosbox = updateDosbox;
exports.dosboxAsyncify = dosboxAsyncify;
exports.dosboxXAsyncify = dosboxXAsyncify;
